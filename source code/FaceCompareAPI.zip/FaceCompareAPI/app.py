import os
from PIL import Image
import numpy as np
import pandas as pd
import flask
import werkzeug
from werkzeug.utils import secure_filename
from werkzeug.exceptions import HTTPException
#from skimage import io
import glob
import sys
import requests
from azure.cognitiveservices.vision.face import FaceClient
from msrest.authentication import CognitiveServicesCredentials

app = flask.Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 10 * 1024 * 1024

KEY = 'c4b5055b663349dd939084ccbcefaad2'
ENDPOINT = 'https://faceidentifyfromvideo.cognitiveservices.azure.com/'

face_client = FaceClient(ENDPOINT, CognitiveServicesCredentials(KEY))

global image_UploadPath 
image_UploadPath = "./static"
print("1")


def Verified_face(image_lst):
    detect_f = []
    for img in image_lst:
        image = open(img, 'r+b')
        detected_faces = face_client.face.detect_with_stream(image)
        detect_f.append(detected_faces)
    is_identical = ""
    Confidence_Score = ""
    cssColor = ""

    if(len(detect_f[0]) >= 1 and len(detect_f[1]) >= 1):
        faceID1 = detect_f[0][0].face_id
        print(faceID1)
        faceID2 = detect_f[1][0].face_id
        print(faceID2)
        face_verified = face_client.face.verify_face_to_face(faceID1, faceID2)
        if face_verified.is_identical is True:
            is_identical = "Same person on ID Card and Video"
            Confidence_Score = face_verified.confidence
            cssColor = "green"
        else:
            is_identical = "Different person on ID Card and Video"
            Confidence_Score = face_verified.confidence
            cssColor = "red"
    else:
        if(len(detect_f[0]) == 0):
            is_identical = "No person appeared on file 1"
            Confidence_Score = 0
            cssColor = "red"
        else:
            is_identical = "No person appeared on file 2"
            Confidence_Score = 0
            cssColor = "red"
    return is_identical, Confidence_Score, cssColor

print("2")

def upload_image():
    global Secure_imgName
    global Secure_VideoName
    print("start upload")
    if flask.request.method == "POST":
        print("img start")
        img_file = flask.request.files["image_file"]
        vid_file = flask.request.files["file"]
        Secure_imgName = secure_filename(img_file.filename)
        Secure_VideoName = secure_filename(vid_file.filename)
        if ((Secure_imgName != "") and (Secure_VideoName != "")):            
            print("img path", image_UploadPath)
            img_path = os.path.join(image_UploadPath, Secure_imgName)
            img_file.save(img_path)  # Saving the image in the specified path.
            print("Image uploaded successfully.")
            vid_path = os.path.join(image_UploadPath, Secure_VideoName)
            vid_file.save(vid_path)
            print("video uploaded successfully")

            return flask.redirect(flask.url_for(endpoint="verify"))
        else:
            return flask.redirect(flask.url_for(endpoint="error"))
    return "Image upload failed."

app.add_url_rule(rule="/upload/", endpoint="upload",view_func=upload_image, methods=["POST"])


def redirect_upload():
    return flask.render_template(template_name_or_list="upload_image.html")
app.add_url_rule(rule="/", endpoint="homepage", view_func=redirect_upload)

def error():
    return flask.render_template(template_name_or_list="error.html")
app.add_url_rule(rule="/error",endpoint="error",view_func=error)

def verify():
    img_ls=[]
    img_path = os.path.join(image_UploadPath, Secure_imgName)
    img_ls.append(img_path)
    sys.stdout.write("img: "+img_ls[0]+' :|')
    sys.stdout.flush()
    vid_path = os.path.join(image_UploadPath, Secure_VideoName)
    os.system("python get_frames.py -i "+vid_path+" -f 1")
    file_name = os.listdir('./static/Video_Frame')
    length = len(file_name)/2
    print(length)

    vidimage_Name = "frame" + str(round(length))+".jpg"
    
    vid_imgPath =image_UploadPath+'/Video_Frame/'+vidimage_Name
    img_ls.append(vid_imgPath)
    sys.stdout.write("videoUrl: "+vid_imgPath+' :|')
    sys.stdout.flush()
    print(vid_imgPath)
    #imgUrl1 = "https://csdx.blob.core.windows.net/resources/Face/Images/Family1-Dad1.jpg"
    identical, confidence_score, cssClass = Verified_face(img_ls)
    os.remove(img_path)
    os.remove(vid_path)
    pa = os.getcwd() + '/static/Video_Frame/*'
    rP =glob.glob(pa) 
    for items in rP:
        os.remove(items)
    return flask.render_template(template_name_or_list="prediction_result.html", cssClass=cssClass, predicted_class=identical, confidence_score=confidence_score)

app.add_url_rule(rule="/verify/", endpoint="verify", view_func=verify)

