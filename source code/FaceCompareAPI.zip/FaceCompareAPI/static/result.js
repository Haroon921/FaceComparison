function show_alert(predicted_class){
alert("Processing Finished.\n Face Verified Result *"+predicted_class+"*.");
}

//var element = document.getElementById('pClassID');
// alert(element);
